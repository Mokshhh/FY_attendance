class Strings {
  static const String contra_wireframe_kit = "Contra Flutter kit";
  static const String contra_wireframe_kit_next_line = "Contra Flutter \nUikit";
  static const String open_source = "OPEN SOURCE";
  static const String contra_wireframe_kit_page_text =
      "Flutter UiKit will be usefull for learning purpose especially for beginners";
}
