import 'package:do_my_homework/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class ButtonPlainWithIcon extends StatelessWidget {
  final String text;
  final String iconPath;
  final VoidCallback callback;
  final bool isPrefix;
  final bool isSuffix;
  final Color color;
  final Color textColor;
  final double? size;

  const ButtonPlainWithIcon(
      {required this.text,
      required this.callback,
      required this.isPrefix,
      required this.isSuffix,
      required this.iconPath,
      required this.color,
      this.size,
      required this.textColor});

  @override
  Widget build(BuildContext context) {
    return ButtonTheme(
      minWidth: size != null ? size! : MediaQuery.of(context).size.width,
      child: MaterialButton(
        padding: EdgeInsets.all(16),
        color: color,
        onPressed: callback,
        textColor: textColor,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            isPrefix
                ? Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8.0),
                    child: SvgPicture.asset(
                      iconPath,
                      color: white,
                      width: 24,
                      height: 24,
                    ),
                  )
                : SizedBox(),
            Text(
              text,
              style: TextStyle(fontSize: 21.0, fontWeight: FontWeight.bold),
            ),
            isSuffix
                ? Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8.0),
                    child: SvgPicture.asset(iconPath),
                  )
                : SizedBox(),
          ],
        ),
        shape: RoundedRectangleBorder(
            borderRadius: new BorderRadius.circular(16.0)),
      ),
    );
  }
}
